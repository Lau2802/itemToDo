package com.itemToDo.itemToDo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemToDoApplicationTests {

	@Test
	void contextLoads() {
	}

}
