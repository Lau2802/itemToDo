package com.itemToDo.itemToDo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemToDoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItemToDoApplication.class, args);
	}

}
